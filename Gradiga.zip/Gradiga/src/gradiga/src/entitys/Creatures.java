package gradiga.src.entitys;

import gradiga.src.main.Game;

public abstract class Creatures extends Entity {

	public Creatures(Game game,float x, float y, int width, int height) {
		super(game, x, y, width, height);
		
	}

}
