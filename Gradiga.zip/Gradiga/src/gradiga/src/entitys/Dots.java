package gradiga.src.entitys;

import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;

import gradiga.src.main.Game;

public class Dots extends Creatures {

	private Color currentColor = Color.white;
	private Color nextColor1 = Color.white;
	private Color nextColor2 = Color.white;

	private Random rand = new Random();
	private int r, g, b;
	
	public Dots(Game game,float x, float y, int width, int height) {
		super(game,x, y, width, height);
		this.game = game;
		
	}

	@Override
	public void tick() {
		
		y += 35;
		
		if(y >= 1000) {
			
			y = 0;
			x = rand.nextInt(1000);
			
			r = rand.nextInt(255);
			g = rand.nextInt(255);
			b = rand.nextInt(255);
			
			currentColor = new Color(r, g, b);
			
			r = rand.nextInt(255);
			g = rand.nextInt(255);
			b = rand.nextInt(255);
			
			nextColor1 = new Color(r, g, b);
			
			r = rand.nextInt(255);
			g = rand.nextInt(255);
			b = rand.nextInt(255);
			
			nextColor2 = new Color(r, g, b);
			
			if(game.getKeyManager().w == true) {
				height+=2;
			}
			if(game.getKeyManager().s == true) {
				height-=2;
			}
			if(game.getKeyManager().a == true) {
				width-=2;
			}
			if(game.getKeyManager().d == true) {
				width+=2;
			}
			
		}
	}

	@Override
	public void render(Graphics g) {
		g.setColor(currentColor);
		
		g.fillArc( (int) x, (int) y, width, height, 0, 360);
		
		g.fillArc( (int) x + rand.nextInt(1000), (int) y + rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x + rand.nextInt(1000), (int) y + rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x + rand.nextInt(1000), (int) y + rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x + rand.nextInt(1000), (int) y + rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x + rand.nextInt(1000), (int) y + rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x - rand.nextInt(1000), (int) y - rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x - rand.nextInt(1000), (int) y - rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x - rand.nextInt(1000), (int) y - rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x - rand.nextInt(1000), (int) y - rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x - rand.nextInt(1000), (int) y - rand.nextInt(1000), width, height, 0, 360);

		g.setColor(nextColor1);
		
		g.fillArc( (int) x + rand.nextInt(1000), (int) y + rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x + rand.nextInt(1000), (int) y + rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x + rand.nextInt(1000), (int) y + rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x + rand.nextInt(1000), (int) y + rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x + rand.nextInt(1000), (int) y + rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x - rand.nextInt(1000), (int) y - rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x - rand.nextInt(1000), (int) y - rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x - rand.nextInt(1000), (int) y - rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x - rand.nextInt(1000), (int) y - rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x - rand.nextInt(1000), (int) y - rand.nextInt(1000), width, height, 0, 360);

		g.setColor(nextColor2);
		
		g.fillArc( (int) x + rand.nextInt(1000), (int) y + rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x + rand.nextInt(1000), (int) y + rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x + rand.nextInt(1000), (int) y + rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x + rand.nextInt(1000), (int) y + rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x + rand.nextInt(1000), (int) y + rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x - rand.nextInt(1000), (int) y - rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x - rand.nextInt(1000), (int) y - rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x - rand.nextInt(1000), (int) y - rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x - rand.nextInt(1000), (int) y - rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x - rand.nextInt(1000), (int) y - rand.nextInt(1000), width, height, 0, 360);
		
		g.setColor(nextColor1);
		
		g.fillArc( (int) x + rand.nextInt(1000), (int) y + rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x + rand.nextInt(1000), (int) y + rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x + rand.nextInt(1000), (int) y + rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x + rand.nextInt(1000), (int) y + rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x + rand.nextInt(1000), (int) y + rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x - rand.nextInt(1000), (int) y - rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x - rand.nextInt(1000), (int) y - rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x - rand.nextInt(1000), (int) y - rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x - rand.nextInt(1000), (int) y - rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x - rand.nextInt(1000), (int) y - rand.nextInt(1000), width, height, 0, 360);
		
		g.setColor(nextColor2);
		
		g.fillArc( (int) x + rand.nextInt(1000), (int) y + rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x + rand.nextInt(1000), (int) y + rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x + rand.nextInt(1000), (int) y + rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x + rand.nextInt(1000), (int) y + rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x + rand.nextInt(1000), (int) y + rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x - rand.nextInt(1000), (int) y - rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x - rand.nextInt(1000), (int) y - rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x - rand.nextInt(1000), (int) y - rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x - rand.nextInt(1000), (int) y - rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x - rand.nextInt(1000), (int) y - rand.nextInt(1000), width, height, 0, 360);
		
		g.setColor(currentColor);
		
		g.fillArc( (int) x, (int) y, width, height, 0, 360);
		
		g.fillArc( (int) x + rand.nextInt(1000), (int) y + rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x + rand.nextInt(1000), (int) y + rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x + rand.nextInt(1000), (int) y + rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x + rand.nextInt(1000), (int) y + rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x + rand.nextInt(1000), (int) y + rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x - rand.nextInt(1000), (int) y - rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x - rand.nextInt(1000), (int) y - rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x - rand.nextInt(1000), (int) y - rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x - rand.nextInt(1000), (int) y - rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x - rand.nextInt(1000), (int) y - rand.nextInt(1000), width, height, 0, 360);

		g.setColor(nextColor1);
		
		g.fillArc( (int) x + rand.nextInt(1000), (int) y + rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x + rand.nextInt(1000), (int) y + rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x + rand.nextInt(1000), (int) y + rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x + rand.nextInt(1000), (int) y + rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x + rand.nextInt(1000), (int) y + rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x - rand.nextInt(1000), (int) y - rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x - rand.nextInt(1000), (int) y - rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x - rand.nextInt(1000), (int) y - rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x - rand.nextInt(1000), (int) y - rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x - rand.nextInt(1000), (int) y - rand.nextInt(1000), width, height, 0, 360);

		g.setColor(nextColor2);
		
		g.fillArc( (int) x + rand.nextInt(1000), (int) y + rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x + rand.nextInt(1000), (int) y + rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x + rand.nextInt(1000), (int) y + rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x + rand.nextInt(1000), (int) y + rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x + rand.nextInt(1000), (int) y + rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x - rand.nextInt(1000), (int) y - rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x - rand.nextInt(1000), (int) y - rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x - rand.nextInt(1000), (int) y - rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x - rand.nextInt(1000), (int) y - rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x - rand.nextInt(1000), (int) y - rand.nextInt(1000), width, height, 0, 360);
		
		g.setColor(nextColor1);
		
		g.fillArc( (int) x + rand.nextInt(1000), (int) y + rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x + rand.nextInt(1000), (int) y + rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x + rand.nextInt(1000), (int) y + rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x + rand.nextInt(1000), (int) y + rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x + rand.nextInt(1000), (int) y + rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x - rand.nextInt(1000), (int) y - rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x - rand.nextInt(1000), (int) y - rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x - rand.nextInt(1000), (int) y - rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x - rand.nextInt(1000), (int) y - rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x - rand.nextInt(1000), (int) y - rand.nextInt(1000), width, height, 0, 360);
		
		g.setColor(nextColor2);
		
		g.fillArc( (int) x + rand.nextInt(1000), (int) y + rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x + rand.nextInt(1000), (int) y + rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x + rand.nextInt(1000), (int) y + rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x + rand.nextInt(1000), (int) y + rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x + rand.nextInt(1000), (int) y + rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x - rand.nextInt(1000), (int) y - rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x - rand.nextInt(1000), (int) y - rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x - rand.nextInt(1000), (int) y - rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x - rand.nextInt(1000), (int) y - rand.nextInt(1000), width, height, 0, 360);
		g.fillArc( (int) x - rand.nextInt(1000), (int) y - rand.nextInt(1000), width, height, 0, 360);
	}

}
