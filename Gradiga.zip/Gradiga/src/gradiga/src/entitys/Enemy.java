package gradiga.src.entitys;

import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;

import gradiga.src.main.Game;
import gradiga.src.states.DeathState;
import gradiga.src.states.GameState;
import gradiga.src.states.State;

public class Enemy extends Creatures {

	private int decider;
	private Random rand;
	private Game game;
	
	private Color currentColor = Color.red;
	
	private int speed = 3;
	
	private int r, g, b;
		
	private DeathState deathState;
	
	public Enemy(Game game, float x, float y, int width, int height) {
		super(game, x, y, width, height);
		rand = new Random();
		decider = rand.nextInt(1000);
		this.game = game;
	}

	@Override
	public void tick() {
		
		y += speed;
		
		if(y >= 955) {
			
			r = rand.nextInt(255);
			g = rand.nextInt(255);
			b = rand.nextInt(255);
			
			currentColor = new Color(r, g, b);
			
			y = 0;
			x = rand.nextInt(1000);
			
		}
	}

	@Override
	public void render(Graphics g) {
		
		g.setColor(currentColor);
		g.fillRect((int)x, (int)y, width, height);
		
	}
	
	public void dissapear() {
		
		r = rand.nextInt(255);
		g = rand.nextInt(255);
		b = rand.nextInt(255);
		
		currentColor = new Color(r, g, b);
		
		x = rand.nextInt(1000);
		y = 0;
		GameState.score++;
		speed++;
		
	}
	
	public void hitPlayer() {
		
		
		deathState = new DeathState(game);
		State.setState(deathState);
		
		
	}

}
