package gradiga.src.entitys;

import gradiga.src.main.Game;

public abstract class Objects extends Entity {

	public Objects(Game game, float x, float y, int width, int height) {
		super(game, x, y, width, height);
	}

}
