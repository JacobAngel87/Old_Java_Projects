package gradiga.src.entitys;

import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;

import gradiga.src.main.Game;
import gradiga.src.states.GameState;

public class Player extends Creatures{

	private Game game;
	private float x, y;
	private Enemy enemy;
	private GameState gameState;
	private boolean changer = false;
	private Random rand = new Random();
	private int r, g, b;
	
	public static Color playerColor = Color.blue;
	
	public Player(Game game, float x, float y, int width, int height) {
		super(game, x, y, width, height);
		this.game = game;
		this.x = x;
		this.y = y;
	}

	@Override
	public void tick() {
		
		if(game.getKeyManager().right == true) {
			x += 5;
			
			if(x >= 925) {
				x = 925;
			}
		}
		
		if(game.getKeyManager().left == true) {
			x -= 5;
			
			if(x <= 0) {
				x = 0;
			}
		}
		
		if(game.getKeyManager().up == true && changer == false) {
			changer = true;
		}
		
		if(game.getKeyManager().down == true && changer == true) {
			changer = false;
		}
		
		if(changer == true) {
			r = rand.nextInt(255);
			g = rand.nextInt(255);
			b = rand.nextInt(255);
			
			playerColor = new Color(r, g, b);
		}
		
	}

	@Override
	public void render(Graphics g) {
		g.setColor(playerColor);
		g.fillRect( (int) x, (int) y, width, height);
		
	}
	

	public float getX() {
		return x;
	}
	public float getY() {
		return y;
	}
	
}
