package gradiga.src.entitys;

import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;

import gradiga.src.main.Game;

public class Projectile extends Objects{

	
	private Player player;
	private boolean shooting = false;
	private Game game;
	private boolean changer = true;
	private Random rand = new Random();
	private Color currentColor = Color.white;
	private int r, g, b;
	
	
	public boolean getShooting() {
		return shooting;
	}

	public void setShooting(boolean isShooting) {
		shooting = isShooting;
	}

	public Projectile(Game game, float x, float y, int width, int height) {
		super(game,x, y, width, height);
		this.game = game;
	}

	@Override
	public void tick() {
		
	  if(game.getKeyManager().shoot) {
		  shooting = true;
	  }
	  
	  if(shooting == true) {
		  y-= 25;
	  }
	  
	   if(y <= -25) {
		   y = 900;
		   shooting = false;
	   }
	   
	   if(game.getKeyManager().up == true && changer == true) {
		   changer = false;
	   }
	   if(game.getKeyManager().down == true && changer == false) {
		   changer = true;
	   }
	   
	   /*
	   if(game.getKeyManager().up == true) {
		   width++;
		   height++;
	   }
	   
	   if(game.getKeyManager().down == true) {
		   width--;
		   height--;
	   } 
	   
	  */
	   if(changer == true) {
		   r = rand.nextInt(255);
		   g = rand.nextInt(255);
		   b = rand.nextInt(255);
		   
		   currentColor = new Color(r, g, b);
	   }
	   
	}

	public void render(Graphics g) {

		g.setColor(currentColor);
		g.fillRect((int) x, (int)y, width, height);
		
	}

	
}
