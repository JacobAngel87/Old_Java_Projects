package gradiga.src.main;

import java.awt.Graphics;
import java.awt.image.BufferStrategy;

import gradiga.src.entitys.Enemy;
import gradiga.src.gfx.Display;
import gradiga.src.states.DeathState;
import gradiga.src.states.GameState;
import gradiga.src.states.State;

public class Game implements Runnable {

	
	public int width, height;
	public String title;
	
	public Thread thread;
	
	public BufferStrategy bs;
	public Graphics g;
	
	public Display display;
	
	private boolean running = false;
	
	private State gameState;
	private State deathState;
	
	private KeyManager keyManager;
	
	private Enemy enemy;
	
	public Game(int width, int height, String title) {
		this.width = width;
		this.height = height;
		this.title = title;
		
		keyManager = new KeyManager();
	}
	
	

	public void run() {
		running = true;
		init();
		
		int fps = 120;
		double timePerTick = 1000000000 / fps;
		double delta = 0;
		long now;
		long lastTime = System.nanoTime();
		long timer = 0;
		long ticks = 0;
		
		while(running) {
			
			now = System.nanoTime();
			delta += (now - lastTime) / timePerTick;
			timer += now - lastTime;
			lastTime = now;
			
			 if(delta >= 1) {
					tick();
					render();
					ticks++;
					delta--;
				  }
				  
				  if(timer >= 1000000000) {
					System.out.println("fps: " + ticks);
		  			ticks = 0;
		  			timer = 0;
				  }
			
		}
	}
	
	public synchronized void start() {
		if(running)
			return;
		thread = new Thread(this);
		thread.run();
	}
	
	public synchronized void stop() {
		if(!running)
			return;
		try {
			thread.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	private void init() {
		display = new Display(width, height, title);
		display.getJFrame().addKeyListener(keyManager);
		gameState = new GameState(this);
		deathState = new DeathState(this);
		State.setState(deathState);
		
	}
	
	private void tick() {
		keyManager.tick();
	
		if(State.getState() != null) {
			State.getState().tick();
			
		}
		
	}
	
	
	public KeyManager getKeyManager() {
		return keyManager;
	}
	
	private void render() {
		bs = display.getCanvas().getBufferStrategy();
		if(bs == null) {
			display.getCanvas().createBufferStrategy(3);
			return;
		}
		g = bs.getDrawGraphics();
		g.clearRect(0, 0, width, height);
		
		//Start
		
		if(State.getState() != null) {
			State.getState().render(g);
		}
		
		//Stop
		
		bs.show();
		g.dispose();
	}
	
}
