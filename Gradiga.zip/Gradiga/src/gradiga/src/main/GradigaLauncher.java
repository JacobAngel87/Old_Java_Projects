package gradiga.src.main;

public class GradigaLauncher {

	public static void main(String[] args) {
	
		Game game = new Game(1000, 700, "Gradiga");
		game.start();
	}
	
}
