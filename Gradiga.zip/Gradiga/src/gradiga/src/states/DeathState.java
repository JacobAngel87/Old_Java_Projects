package gradiga.src.states;

import java.awt.Color;
import java.awt.Graphics;

import gradiga.src.entitys.Dots;
import gradiga.src.main.Game;

public class DeathState extends State{

	private Dots background;
	private Dots background2;
	private Dots background3;
	
	private Dots background4;
	private Dots background5;
	private Dots background6;
	
	public DeathState(Game game) {
		super(game);
		background = new Dots(game, 500,500, 4,4);
		background2 = new Dots(game, 0, 0, 4,4);
		background3 = new Dots(game, 1000, 1000, 4,4);
		
		background4 = new Dots(game, 0,1000, 4,4);
		background5 = new Dots(game, 1000, 0, 4,4);
		background6 = new Dots(game, 600, 600, 4,4);
	}

	@Override
	public void tick() {
		background.tick();
		background2.tick();
		background3.tick();
		background4.tick();
		background5.tick();
		background6.tick();
		
		
		
		if(game.getKeyManager().enter == true) {
		
			GameState.score = 0;
			State gameState = new GameState(game);
			State.setState(gameState);
			
		}
		
		
	}

	@Override
	public void render(Graphics g) {
		
		g.setColor(Color.black);
		g.fillRect(0, 0, 1000, 1000);
		background.render(g);
		background2.render(g);
		background3.render(g);
		background4.render(g);
		background5.render(g);
		background6.render(g);
	}

}
