package gradiga.src.states;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;

import gradiga.src.entitys.Dots;
import gradiga.src.entitys.Enemy;
import gradiga.src.entitys.Player;
import gradiga.src.entitys.Projectile;
import gradiga.src.main.Game;

public class GameState extends State {

	
	private Game game;
	public Player player;
	public Projectile bullet;
	public Projectile bullet2;
	public Projectile bullet3;
	public Enemy enemy;
	public Enemy enemy2;
	public Enemy enemy3;
	public Enemy enemy4;
	public Dots background;
	private Dots background2;
	private Dots background3;
	private Dots background4;
	private Dots background5;
	private Dots background6;
	
	public static int score = 0;
	
	public GameState(Game game) {
		
		super(game);
		this.game = game;
		
		player = new Player(game, 500, 625, 75, 75);
		
		bullet = new Projectile(game, player.getX() + 33 , 950, 10, 10);
		bullet2 = new Projectile(game, player.getX(), 950, 10, 10);
		bullet3 = new Projectile(game, player.getX()+ 65, 950, 10, 10);
		
		enemy  = new Enemy(game, 425, 0, 45, 45);
		enemy2 = new Enemy(game, 300, 0, 45, 45);
		enemy3 = new Enemy(game, 250, 0, 45, 45);
		enemy4 = new Enemy(game, 600, 0, 45, 45);
		
		background  = new Dots(game, 500, 500, 4, 4);
		background2 = new Dots(game, 0, 0, 4,4);
		background3 = new Dots(game, 1000, 1000, 4,4);
		
		background4 = new Dots(game, 0,1000, 4,4);
		background5 = new Dots(game, 1000, 0, 4,4);
		background6 = new Dots(game, 500, 500, 4,4);
		
		
	}

	public void tick() {
		
		background.tick();
		background2.tick();
		background3.tick();
		background4.tick();
		background5.tick();
		background6.tick();
		
		bullet.tick();
		player.tick();
		enemy.tick();
		
		if(score >= 2) {
			enemy2.tick();
		}
		if(score >= 5) {
			enemy3.tick();
		}
		if(score >= 15) {
			enemy4.tick();
		}
		
		 
		 	if(score >= 20) {
			bullet2.tick();
			bullet3.tick();
     	}
		
		
		
		Rectangle bulletRect = new Rectangle((int) bullet.getX(),(int) bullet.getY(), bullet.getWidth(), bullet.getHeight());
		Rectangle bulletRect2 = new Rectangle((int) bullet2.getX(),(int) bullet2.getY(), bullet2.getWidth(), bullet2.getHeight());
		Rectangle bulletRect3 = new Rectangle((int) bullet3.getX(),(int) bullet3.getY(), bullet3.getWidth(), bullet3.getHeight());


		Rectangle enemyRect = new Rectangle((int) enemy.getX(), (int) enemy.getY(), enemy.getWidth(), enemy.getHeight());
		
		Rectangle playerRect = new Rectangle((int) player.getX(), (int) player.getY(), player.getWidth(), player.getHeight());
		
		Rectangle enemyRect2 = new Rectangle((int) enemy2.getX(), (int) enemy2.getY(), enemy2.getWidth(), enemy2.getHeight());
		Rectangle enemyRect3 = new Rectangle((int) enemy3.getX(), (int) enemy3.getY(), enemy3.getWidth(), enemy3.getHeight());
		Rectangle enemyRect4 = new Rectangle((int) enemy4.getX(), (int) enemy4.getY(), enemy4.getWidth(), enemy4.getHeight());

		
		
		if(bulletRect.intersects(enemyRect)) {
			enemy.dissapear();
		}
		
		if(score >= 2) {
			
		if(bulletRect.intersects(enemyRect2)) {
			enemy2.dissapear();
			}
		}
		if(score >= 5) {
			
			if(bulletRect.intersects(enemyRect3)) {
				enemy3.dissapear();
				}
			}
		if(score >= 15) {
			
			if(bulletRect.intersects(enemyRect4)) {
				enemy4.dissapear();
				}
			}
		
		if(bulletRect2.intersects(enemyRect)) {
			enemy.dissapear();
		}
		
		if(score >= 2) {
			
		if(bulletRect2.intersects(enemyRect2)) {
			enemy2.dissapear();
			}
		}
		if(score >= 5) {
			
			if(bulletRect2.intersects(enemyRect3)) {
				enemy3.dissapear();
				}
			}
		if(score >= 15) {
			
			if(bulletRect2.intersects(enemyRect4)) {
				enemy4.dissapear();
				}
			}
		if(bulletRect3.intersects(enemyRect)) {
			enemy.dissapear();
		}
		
		if(score >= 2) {
			
		if(bulletRect3.intersects(enemyRect2)) {
			enemy2.dissapear();
			}
		}
		if(score >= 5) {
			
			if(bulletRect3.intersects(enemyRect3)) {
				enemy3.dissapear();
				}
			}
		if(score >= 15) {
			
			if(bulletRect3.intersects(enemyRect4)) {
				enemy4.dissapear();
				}
			}
	
		if(bullet.getShooting() == false) {
			bullet.setX(player.getX() + 33);
		}
		if(bullet2.getShooting() == false) {
			bullet2.setX(player.getX() );
		}
		if(bullet3.getShooting() == false) {
			bullet3.setX(player.getX() + 65);
		}
	
	
		if(enemyRect.intersects(playerRect)) {
			enemy.hitPlayer();
			
		}
		if(score >= 2) {
			if(enemyRect2.intersects(playerRect)) {
				enemy2.hitPlayer();
				
			}
		}
		if(score >= 5) {
			if(enemyRect3.intersects(playerRect)) {
				enemy3.hitPlayer();
				
			}
		}
		if(score >= 15) {
			if(enemyRect4.intersects(playerRect)) {
				enemy4.hitPlayer();
				
			}
		}
	}

	public void render(Graphics g) {
		
		g.setColor(Color.black);
		g.fillRect(0, 0, 1000, 1000);
		
		background.render(g);
		background2.render(g);
		background3.render(g);
		background4.render(g);
		background5.render(g);
		background6.render(g);
		
		bullet.render(g);
		
	
		 	if(score >= 20) {
			bullet2.render(g);
			bullet3.render(g);
			}
		
		
		player.render(g);
		
		enemy.render(g);
			
		if(score >= 2) {
			enemy2.render(g);
		}
		
		if(score >= 5) {
			enemy3.render(g);
		}
		if(score >= 15) {
			enemy4.render(g);
		}
		
		
	}

}
