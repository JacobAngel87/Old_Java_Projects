package gradiga.src.states;

import java.awt.Graphics;

import gradiga.src.main.Game;

public abstract class State {
	
	
	//Game State Manager
	
	private static State currentState = null;
	
	public static State getState() {
		return currentState;
	}
	public static void setState(State state) {
		currentState = state;
	}
	
	
	//Constructor 
	
	protected Game game;
	
	public State(Game game) {
		this.game = game;
	}
	
	// Abstract Classes
	public abstract void tick();
	public abstract void render(Graphics g);
}
