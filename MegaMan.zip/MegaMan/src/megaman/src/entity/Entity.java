package megaman.src.entity;

import java.awt.Graphics;

public abstract class Entity {
	
	public abstract void tick();
	public abstract void render(Graphics g);
	
}
