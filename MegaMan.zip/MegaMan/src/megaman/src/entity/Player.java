package megaman.src.entity;

import java.awt.Color;
import java.awt.Graphics;

import megaman.src.main.Game;

public class Player extends Entity {
	
	private int width, height, x, y;
	private Game game;
	private double xVelo, yVelo;
	private double gravity, speed;
	private boolean falling = true;
	
	public Player(int x, int y, Game game) {
		this.game = game;
		this.x = x;
		this.y = y;
		width = game.width / 20;
		height = game.height / 10;
		gravity = 0.05;
		speed = 0.2;
	}
	
	public void tick() {
		if(game.getKeyManager().d == true) {
			xVelo += speed;
			
			if(xVelo >= 3) {
				xVelo = 3;
			}
		}
		else if(game.getKeyManager().a == true) {
			xVelo -= speed;
			
			if(xVelo <= -3) {
				xVelo = -3;
			}
		}
		
		else {
			if(xVelo > 0) {
				xVelo -= speed / 1.5;
				if(xVelo <= 0) {
					xVelo = 0;
				}
			}
			else if(xVelo < 0) {
				xVelo += speed/ 1.5;
				if(xVelo >= 0) {
					xVelo = 0;
				}
			}
		}
		
		if(falling == true) {
			yVelo += gravity;
		}
		if(falling == false) {
			yVelo = 0;
		}
		
		if(xVelo != 0) {
			move(xVelo);
		}
		if(yVelo != 0) {
			fall(yVelo);
		}
	}
	
	public void move(double velo) {
		x += velo;
	}
	public void fall(double velo) {
		y += velo;
	}
	public void onFloor() {
		falling = false;
	}
	
	public void render(Graphics g) {
		g.setColor(Color.blue);
		g.fillRect(x, y, width, height);
	}
	
	public int getX() {
		return x;
	}
	public int getY() {
		return y;
	}
	public int getWidth() {
		return width;
	}
	public int getHeight() {
		return height;
	}

}
