package megaman.src.gfx;

import java.awt.Canvas;
import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.JFrame;

public class Display {
	public int width, height;
	private String title;
	private JFrame frame;
	private Canvas canvas;
	
	public Display(int width,int height, String title) {
		
		this.width = width;
		this.height = height;
		this.title = title;
		
		frame = new JFrame(title);
		canvas = new Canvas();
		
		makeDisplay();
	}
	
	private void makeDisplay() {
		
		frame.setSize(width, height);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		frame.setResizable(false);
		frame.setVisible(true);
		
		canvas.setPreferredSize(new Dimension(width, height));
		canvas.setMaximumSize(new Dimension(width, height));
		canvas.setMinimumSize(new Dimension(width, height));
		
		frame.add(canvas);
		frame.pack();
		
	}
	public JFrame getJFrame() {
		return frame;
	}
	public Canvas getCanvas() {
		return canvas;
	}
	
}
