package megaman.src.main;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class KeyManager implements KeyListener {

	
	private boolean[] keys;
	public boolean right, left, up, down, shoot, enter, shift, w, s, a, d;
	
	public KeyManager() {
		keys = new boolean[256];
	}
	
	public void tick() {
		right = keys[KeyEvent.VK_RIGHT];
		left = keys[KeyEvent.VK_LEFT];
		up = keys[KeyEvent.VK_UP];
		down = keys[KeyEvent.VK_DOWN];
		w = keys[KeyEvent.VK_W];
		s = keys[KeyEvent.VK_S];
		a = keys[KeyEvent.VK_A];
		d = keys[KeyEvent.VK_D];
		shoot = keys[KeyEvent.VK_SPACE];
		enter = keys[KeyEvent.VK_ENTER];
		shift = keys[KeyEvent.VK_SHIFT];
		
				
	}

	public void keyTyped(KeyEvent e) {
	}

	public void keyPressed(KeyEvent e) {
		keys[e.getKeyCode()] = true;
	}

	public void keyReleased(KeyEvent e) {
		keys[e.getKeyCode()] = false;
	}
	
}
