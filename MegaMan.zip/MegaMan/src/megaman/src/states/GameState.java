package megaman.src.states;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.Random;

import megaman.src.entity.Floor;
import megaman.src.entity.Player;
import megaman.src.main.Game;

public class GameState extends State {
	private Game game;
	private int tileSize;
	private Random rand;
	private Player player;
	private Floor floor;
	private Rectangle playerBounds, floorBounds;
	
	public GameState(Game game) {
		this.game = game;
		tileSize = game.TILE_SIZE;
		rand = new Random();
		player = new Player(0, 0, game);
		floor = new Floor(0, 800, game.width, game.height / 10);
		playerBounds = new Rectangle(player.getX(), player.getY(), player.getWidth(), player.getHeight());
		floorBounds = new Rectangle(floor.getX(), floor.getY(), floor.getWidth(), floor.getHeight());
	}

	@Override
	public void tick() {
		
		player.tick();
		floor.tick();
		
		playerBounds = new Rectangle(player.getX(), player.getY(), player.getWidth(), player.getHeight());
		floorBounds = new Rectangle(floor.getX(), floor.getY(), floor.getWidth(), floor.getHeight());
		
		if(playerBounds.intersects(floorBounds)) {
			player.onFloor();
		}
	}

	@Override
	public void render(Graphics g) {
		
		g.setColor(Color.red);
		for(int i = 0; i < game.width / tileSize; i++) {
			for(int j = 0; j < game.height / tileSize; j++) {
				g.drawRect(i * tileSize, j * tileSize, tileSize, tileSize);
			}
		}
	   floor.render(g);
	   player.render(g);
	}
	
}
