
public class ImageMovements {

	// Picture Movement code
	
/*
	if(topGoingUp == true) {
		topY--;
		if(topY == 0) {
			topGoingUp = false;
			topGoingDown = true;
		}
	}
	if(topGoingDown == true) {
		topY++;
		if(topY == 861) {
			topGoingDown = false;
			topGoingUp = true;
		}
	}
	if(bottomGoingDown == true) {
		bottomY++;
		if(bottomY == 861) {
			bottomGoingDown = false;
			bottomGoingUp = true;
		}
	}
	if(bottomGoingUp == true) {
		bottomY--;
		if(bottomY == 0) {
			bottomGoingUp = false;
			bottomGoingDown = true;
		}
	}
		*/		
}
