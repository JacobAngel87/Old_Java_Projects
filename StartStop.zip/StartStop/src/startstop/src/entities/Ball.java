package startstop.src.entities;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.util.Random;

import startstop.src.gfx.ImageLoader;
import startstop.src.main.Game;
import startstop.src.states.EndState;
import startstop.src.states.MenuState;
import startstop.src.states.State;

public class Ball extends Pannel{

	private BufferedImage ball = ImageLoader.loadImage("/textures/smallBall.png");
	
	private BufferedImage currentLeftScore = ImageLoader.loadImage("/textures/0.png");
	private BufferedImage currentRightScore = ImageLoader.loadImage("/textures/0.png");
	
	private BufferedImage one = ImageLoader.loadImage("/textures/1.png");
	private BufferedImage two = ImageLoader.loadImage("/textures/2.png");
	private BufferedImage three = ImageLoader.loadImage("/textures/3.png");
	private BufferedImage four = ImageLoader.loadImage("/textures/4.png");
	private BufferedImage five = ImageLoader.loadImage("/textures/5.png");
	private BufferedImage six = ImageLoader.loadImage("/textures/6.png");
	private BufferedImage seven = ImageLoader.loadImage("/textures/7.png");
	private BufferedImage eight = ImageLoader.loadImage("/textures/8.png");
	private BufferedImage nine = ImageLoader.loadImage("/textures/9.png");
	
	private EndState endState;
	
	private Random rand;
	private int decider;
	private int random = 1;
	
	private Game game;
	
	private boolean upLeft = false;
	private boolean downLeft = false;
	private boolean upRight = false;
	private boolean downRight = false;
	
	private int rightScoreDecider = 0;
	private int leftScoreDecider = 0;
	
	private boolean didLeftSideWin = false;
	private boolean didRightSideWin = false;
		
	public Ball(Game game, float x, float y, int width, int height) {
		super(x, y, Pannel.defaultBallWidth, Pannel.defaultBallHeight);
		this.game = game;
		endState = new EndState(game);
		rand = new Random();
		decider = rand.nextInt(4);
		if(decider == 0) {
			upLeft = true;
		}
		
		else if(decider == 1) {
			downLeft = true;
		}
		else if(decider == 2) {
			downRight = true;
		}
		else if(decider == 3) {
			upRight = true;
		}
	
	}

	@Override
	public void tick() {
		
		if(upLeft == true) {
			x -= random;
			y -= random;
		}
		
		if(downRight == true) {
			x += random;
			y += random;
		}
		if(downLeft == true) {
			x -= random;
			y += random;
		}
		if(upRight == true) {
			x += random;
			y -= random;
		}
		
		if(y <= 0 && upRight == true) {
			upRight = false;
			downRight = true;
		}
		if(y <= 0 && upLeft == true) {
			upLeft = false;
			downLeft = true;
		}
		if(y >= 650 && downRight == true) {
			downRight = false;
			upRight = true;
		}
		if(y >= 650 && downLeft == true) {
			downLeft = false;
			upLeft = true;
		}
		
		if(x >= 1000) {
			int newX = rand.nextInt(25);
			int newY = rand.nextInt(25);
			newX += 500;
			newY += 500;
			
			x = newX;
			y = newY;
			random = 2;
			leftScoreDecider++;
		}
       if(x <= 0) {
			int newX = rand.nextInt(25);
			int newY = rand.nextInt(25);
			newX += 500;
			newY += 500;
			
			x = newX;
			y = newY;
			random = 2;
			rightScoreDecider++;
		}
       
       if(leftScoreDecider == 1) {
    	   currentLeftScore = one;
       }
       if(leftScoreDecider == 2) {
    	   currentLeftScore = two;
       }
       if(leftScoreDecider == 3) {
    	   currentLeftScore = three;
       }
       if(leftScoreDecider == 4) {
    	   currentLeftScore = four;
       }
       if(leftScoreDecider == 5) {
    	   currentLeftScore = five;
       }
       if(leftScoreDecider == 6) {
    	   currentLeftScore = six;
       }
       if(leftScoreDecider == 7) {
    	   currentLeftScore = seven;
       }
       if(leftScoreDecider == 8) {
    	   currentLeftScore = eight;
       }
       if(leftScoreDecider == 9) {
    	   currentLeftScore = nine;
       }
       
       if(leftScoreDecider == 10) {
    	   
    	   game.setRightSideWin(true);
    	   didRightSideWin = true;
    	   
    	   upLeft = false;
    	   downLeft = false;
    	   upRight = false;
    	   downRight = false;
       }
       
       
       if(rightScoreDecider == 1) {
    	   currentRightScore = one;
       }
       if(rightScoreDecider == 2) {
    	   currentRightScore = two;
       }
       if(rightScoreDecider == 3) {
    	   currentRightScore = three;
       }
       if(rightScoreDecider == 4) {
    	   currentRightScore = four;
       }
       if(rightScoreDecider == 5) {
    	   currentRightScore = five;
       }
       if(rightScoreDecider == 6) {
    	   currentRightScore = six;
       }
       if(rightScoreDecider == 7) {
    	   currentRightScore = seven;
       }
       if(rightScoreDecider == 8) {
    	   currentRightScore = eight;
       }
       if(rightScoreDecider == 9) {
    	   currentRightScore = nine;
       }
       
       if(rightScoreDecider == 10) {
    	   
    	   game.setLeftSideWin(true);
    	   didLeftSideWin = true;
    	   upLeft = false;
    	   downLeft = false;
    	   upRight = false;
    	   downRight = false;
       }
       
       
       if(didLeftSideWin == true || didRightSideWin == true) {
    	   State.setState(endState);
       }
       
		
    }
	
	public void getNewRandom() {
	  	random = rand.nextInt(12);
	}
		
	
	@Override
	public void render(Graphics g) {
		g.drawImage(currentLeftScore, 350, 0, 100, 100, null);
		g.drawImage(currentRightScore, 525, 0, 100, 100, null);
		
		g.drawImage(ball, (int) x, (int) y, width, height, null);
		
		
	}
	
	public void changeDirectionRightUp() {
		getNewRandom();
		
		upLeft = false;
		downLeft = false;
		downRight = false;
		upRight = true;
		
	}
	
	public void changeDirectionRightDown() {
		getNewRandom();
		
		downLeft = false;
		downRight = true;
		upLeft = false;
		upRight = false;
	}
	
	public void changeDirectionLeftDown() {
		getNewRandom();
		
		downRight = false;
		downLeft = true;
		upRight = false;
		upLeft = false;
		
	}
	public void changeDirectionLeftUp() {
		getNewRandom();
		
		upRight = false;
		upLeft = true;
		downRight = false;
		downLeft = false;
	}
	
}
