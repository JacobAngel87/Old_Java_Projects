package startstop.src.entities;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

import startstop.src.gfx.Assests;
import startstop.src.gfx.ImageLoader;
import startstop.src.main.Game;

public class LeftPannel extends Pannel {

	private Game game;
	private BufferedImage pannel = ImageLoader.loadImage("/textures/Pannel.png");
	
	private float x, y;
	
	public LeftPannel(Game game ,float x, float y) {
		super(x, y, Pannel.defaultPannelWidth, Pannel.defaultPannelHeight);
		this.game = game;
		this.x = x;
		this.y = y;
	}

	public void tick() {
		if(game.getKeyManager().w) {
			y -= 9;
			
			 if(y <= 0) {
					y = 0;
				}
			
		}
		
		if(game.getKeyManager().s) {
			y += 9;
			if(y >= 610) {
				y = 610;
			}
		}
		
		
		
	}

	public void render(Graphics g) {
		g.drawImage(pannel,(int) x, (int) y, width, height, null);
	}
	
	public float getX() {
		return x;
	}
	
	public float getY() {
		return y;
	}
	
}
