package startstop.src.entities;

public abstract class Pannel extends Entity{

	public static final int defaultPannelWidth = 25;
	public static final int defaultPannelHeight = 90;
	
	public static final int defaultBallWidth = 50;
	public static final int defaultBallHeight = 50;
	
	
	public Pannel(float x, float y, int width, int height) {
		super(x, y, width, height);
	}

}
