package startstop.src.gfx;

import java.awt.image.BufferedImage;


public class Assests {

	
	public static BufferedImage topHalf, bottomHalf;
	
	public static final int WIDTH = 181, HEIGHT = 139;
	
	public static void init() {
		
		SpriteSheet sheet = new SpriteSheet(ImageLoader.loadImage("/textures/FF4.png"));
				
		topHalf = sheet.crop(0, 0, WIDTH, HEIGHT);
		
		bottomHalf = sheet.crop(0, HEIGHT, WIDTH, HEIGHT);
		
		
	}
	
}
