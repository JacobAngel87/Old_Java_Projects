package startstop.src.main;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;

import startstop.src.gfx.Assests;
import startstop.src.gfx.Display;
import startstop.src.gfx.ImageLoader;
import startstop.src.states.EndState;
import startstop.src.states.GameState;
import startstop.src.states.MenuState;
import startstop.src.states.State;

public class Game implements Runnable {

	public int width, height;
	public String title;
	public Thread thread;
	public Display display;
	private boolean running = false;
	private BufferStrategy bs;
	private Graphics g;
	private int topX = 400, topY = 500;
	private int bottomX = 400, bottomY = 361;
	
	public boolean leftSideWin = false, rightSideWin = false;
	
	
	
	public boolean isLeftSideWin() {
		return leftSideWin;
	}

	public void setLeftSideWin(boolean leftSideWin) {
		this.leftSideWin = leftSideWin;
	}

	public boolean isRightSideWin() {
		return rightSideWin;
	}

	public void setRightSideWin(boolean rightSideWin) {
		this.rightSideWin = rightSideWin;
	}
	
	private State gameState;
	private State menuState;
	private State endState;
	
	public KeyManager keyManager;
	
	public Game(int width, int height, String title) {
		this.width = width;
		this.title = title;
		this.height = height;
		keyManager = new KeyManager();
		
	}

	public void run()
    {
		running = true;
		init();
		
		int fps = 120;
		double timePerTick = 1000000000 / fps;
		double delta = 0;
		long now;
		long lastTime = System.nanoTime();
		long timer = 0;
		long ticks = 0;
		
		
		while(running) {
			now = System.nanoTime();
			delta += (now - lastTime) / timePerTick;
			timer += now - lastTime;
			lastTime = now;
			
			
		  if(delta >= 1) {
			tick();
			render();
			ticks++;
			delta--;
		  }
		  
		  if(timer >= 1000000000) {
			System.out.println("fps: " + ticks);
  			ticks = 0;
  			timer = 0;
		  }
			
		}
		
				
	}
	
	public synchronized void start() 
	{
	if(running) {	
		return;
	}
	thread = new Thread(this);
	thread.start();
	
	}
	
	public synchronized void stop()
	{	
		if(!running) {
			return;
		}
		running = false;
		try {
			thread.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	private void init() {
		display = new Display(width, height, title);
	    Assests.init();
	    
	    gameState = new GameState(this);
	    menuState = new MenuState(this);
	    endState = new EndState(this);
	    
	    State.setState(menuState);
	    display.getJFrame().addKeyListener(keyManager);
		
	}
	
	private void tick() {
		
		keyManager.tick();
		
		if(State.getState() != null) {
			State.getState().tick();
		}
		
		
	}
	
	private void render() {
	
		bs = display.getCanvas().getBufferStrategy();
		if(bs == null) {
			display.getCanvas().createBufferStrategy(3);
			return;
		}
		g = bs.getDrawGraphics();
		
		g.clearRect(0, 0, width, height);
		
		//Start Draws
		
		
		
		if(State.getState() != null) {
			State.getState().render(g);
		}
		
		//End Draws
		
		bs.show();
		g.dispose();
		

	}
	public KeyManager getKeyManager() {
		return keyManager;
	}
	
}