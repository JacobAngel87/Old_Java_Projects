package startstop.src.states;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

import startstop.src.entities.Ball;
import startstop.src.gfx.ImageLoader;
import startstop.src.main.Game;

public class EndState extends State {
	private Game game;
	
	private BufferedImage right = ImageLoader.loadImage("/textures/right.png");
	private BufferedImage left = ImageLoader.loadImage("/textures/left.png");
	private BufferedImage sideWins = ImageLoader.loadImage("/textures/sideWins.png");
	
	
	public EndState(Game game) {
		super(game);
		this.game = game;
	}

	@Override
	public void tick() {
		
		if(game.getKeyManager().shift == true) {
			State menuState = new MenuState(game);
			State.setState(menuState);
		}
		
	}

	@Override
	public void render(Graphics g) {
		
		g.setColor(Color.black);	
		g.fillRect(0, 0, 1000, 1000);	
		
		// When Right Side Wins do This
		if(game.leftSideWin == true) {
		
		g.drawImage(right, 250, -50, 500, 500, null);
		g.drawImage(sideWins, 250, 400, 500, 500, null);
		
		}
		// When Left Side Wins do this
		if(game.rightSideWin == true) {
			
			g.drawImage(left, 250, 200, 500, 500, null);
			g.drawImage(sideWins, 250, 400, 500, 500, null);

		}
		
	}

}
