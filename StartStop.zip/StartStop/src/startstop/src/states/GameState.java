package startstop.src.states;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.util.Random;

import startstop.src.entities.Ball;
import startstop.src.entities.LeftPannel;
import startstop.src.entities.RightPannel;
import startstop.src.gfx.ImageLoader;
import startstop.src.main.Game;

public class GameState extends State {
	
	private LeftPannel leftPannel;
	private RightPannel rightPannel;
	private Ball ball;
	private Random rand;
	private int decider;
	private BufferedImage spacer = ImageLoader.loadImage("/textures/spacer.png");	
		
	public GameState(Game game) {
		super(game);
		leftPannel = new LeftPannel(game, 75, 200);
		rightPannel = new RightPannel(game, 900, 200);
		ball = new Ball(game, 500, 500, 100, 100);
		rand = new Random();
	}

	public void tick() {
		
		
		
		leftPannel.tick();
		rightPannel.tick();
		ball.tick();
		
		 int rightPannelRectX = (int)rightPannel.getX();
		 int rightPannelRectY = (int) rightPannel.getY();
	     int rightPannelRectWidth = rightPannel.getWidth();
	   	 int rightPannelRectHeight = rightPannel.getHeight();
		
	 	Rectangle RPR = new Rectangle(rightPannelRectX, rightPannelRectY, rightPannelRectWidth, rightPannelRectHeight);
		Rectangle LPR = new Rectangle((int)leftPannel.getX(), (int) leftPannel.getY(),   leftPannel.getWidth(), leftPannel.getHeight());
		Rectangle LBR = new Rectangle((int)ball.getX(), (int) ball.getY(), ball.getWidth(), ball.getHeight());

		
		if(LBR.intersects(RPR)) {
		  decider = rand.nextInt(2);
		  
		  if(decider == 0) {
			  ball.changeDirectionLeftUp();
		  }
		  else {
			  ball.changeDirectionLeftDown();
		  }
		  
		}
		
		else if(LBR.intersects(LPR)) {
	      decider = rand.nextInt(2);
	      if(decider == 0) {
	    	  ball.changeDirectionRightDown();
	      }
	      else {
	    	  ball.changeDirectionRightUp();
	      }
	      
		}
		
	}

	public void addLeftPoint() {
		
	}
	
	public void addRightPoint() {
		
	}
	
	public void render(Graphics g) {
		g.setColor(Color.black);
		g.fillRect(0, 0, 1000, 1000);
		g.drawImage(spacer, 425, 65, 100, 15, null);
		
		leftPannel.render(g);
		rightPannel.render(g);
		ball.render(g);
		
	}

}
