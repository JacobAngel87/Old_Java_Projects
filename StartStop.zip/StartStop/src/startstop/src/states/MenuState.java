package startstop.src.states;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

import startstop.src.gfx.ImageLoader;
import startstop.src.main.Game;


public class MenuState extends State {
	
	private GameState gameState;
	private BufferedImage logo = ImageLoader.loadImage("/textures/pongTitle.png");
	
	public MenuState(Game game) {
		super(game);
		gameState = new GameState(game);
	}

	@Override
	public void tick() {
		if(game.getKeyManager().enter) {
			State.setState(gameState);
		}
	}

	@Override
	public void render(Graphics g) {
		g.setColor(Color.black);
		g.fillRect(0, 0, 1000, 1000);
		
		g.drawImage(logo, 0, 50, 1000, 500, null);
		
		
	}

}
