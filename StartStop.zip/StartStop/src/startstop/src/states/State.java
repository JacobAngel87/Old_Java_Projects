package startstop.src.states;

import java.awt.Graphics;

import startstop.src.main.Game;

public abstract class State {

	// Game State Manager
	
	private static State currentState = null;
	
	public static void setState(State state) {
		currentState = state;
	}
	
	public static State getState() {
		return currentState;
	}
	
	
	// Constructor
	
	protected Game game;
	
	public State(Game game)
	{	
		this.game = game;
	}
	// Abstract Class Methods
	
	public abstract void tick();
	public abstract void render(Graphics g);
	
}
