package tileBasedMovement.src.entity;

import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;

import tileBasedMovement.src.main.Game;

public class Apple extends Entity {

	
	private int tileSize;
	private int x, y;
	private int newX, newY;
	private Random rand;
	private Game game;
	
	public Apple(int x, int y, Game game) {
		this.x = x;
		this.y = y;
		this.game = game;
		tileSize = Game.TILE_SIZE;
		rand = new Random();
	}
	
	public void tick() {
		
	}
	
	public void eaten() {
		newX = rand.nextInt(game.width / tileSize);
		newY = rand.nextInt(game.height / tileSize);
		
		newX *= tileSize;
		newY *= tileSize;
		
		x = newX;
		y = newY;
	}
	
	public int getX() {
		return x;
	}
	
	public int getY() {
		return y;
	}

	@Override
	public void render(Graphics g) {
		g.setColor(Game.appleColor);
		g.fillRect(x, y, tileSize, tileSize);
		
	}

}
