package tileBasedMovement.src.entity;

import java.awt.Graphics;
import java.util.ArrayList;

import tileBasedMovement.src.main.Game;
import tileBasedMovement.src.states.DeathState;
import tileBasedMovement.src.states.State;

public class Snake extends Entity{

	private int x, y;
	private int tileSize;
	
	private Game game;
	
	public ArrayList<SnakeBody> body;
	public int size = 0;
	
	private boolean goingUp, goingDown, goingRight, goingLeft = false;
	
	public Snake(int x, int y, Game game) {
		this.x = x;
		this.y = y;
		this.game = game;
		tileSize = game.TILE_SIZE;
		body = new ArrayList<SnakeBody>();
	}
	
	
	public void grow() {
		SnakeBody bodyPart = new SnakeBody(this);
		body.add(bodyPart);
		size++;
		game.SCORE++;
	}
	
	@Override
	public void tick() {
		
		for(int i = 0; i < body.size(); i++) {
			body.get(i).tick();
		}
		
		for(int i = 2; i < body.size(); i++) {
			if(body.get(i).getX() == x && body.get(i).getY() == y) {
				State deathState = new DeathState(game);
				State.setState(deathState);
			}
		}
		
	if(game.getKeyManager().up == true && goingDown == false) {
		goingUp = true;
		goingDown = false;
		goingRight = false;
		goingLeft = false;
	}
	else if(game.getKeyManager().left == true && goingRight == false) {
		goingUp = false;
		goingDown = false;
		goingRight = false;
		goingLeft = true;
	}
	else if(game.getKeyManager().down == true && goingUp == false) {
		goingUp = false;
		goingDown = true;
		goingRight = false;
		goingLeft = false;
	}
	else if(game.getKeyManager().right == true && goingLeft == false) {
		goingUp = false;
		goingDown = false;
		goingRight = true;
		goingLeft = false;
	}
		
	if(goingUp == true) {
		y -= tileSize;
	}
	
	else if(goingDown == true) {
		y += tileSize;
	}
	else if(goingLeft == true) {
		x -= tileSize;
	}
	else if(goingRight == true) {
		x += tileSize;
	}
		
	if(x >= game.width || x < 0 || y >= game.height || y < 0) {
		State deathState = new DeathState(game);
		State.setState(deathState);
	}
}

	@Override
	public void render(Graphics g) {
		g.setColor(Game.snakeHeadColor);
		g.fillRect(x, y, tileSize, tileSize);
		
		for(int i = 0; i < body.size(); i++) {
			body.get(i).render(g);
		}
	}
	
	public int getX() {
		return x;
	}
	
	public int getY() {
		return y;
	}

}
