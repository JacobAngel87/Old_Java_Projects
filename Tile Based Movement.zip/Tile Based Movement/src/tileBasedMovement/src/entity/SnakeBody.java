package tileBasedMovement.src.entity;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;

import tileBasedMovement.src.main.Game;

public class SnakeBody extends Entity {
	
	private Snake snake;
	
	private int x, y;
	private int lastX, lastY;
	
	private int thisSize;
	
	public SnakeBody(Snake snake) {
		this.snake = snake;
		thisSize = snake.size;
		// Literally all this does is make the body part spawn outside the screen so that you don't see it when it is rendered in.
		x = -25;
		y = -25;
		lastX = -25;
		lastY = -25;
		
	}
	@Override
	public void tick() {
		
		
		if(thisSize < 1) {
		x = snake.getX();
		y = snake.getY();
		lastX = x;
		lastY = y;
		}
		
		else {
			lastX = x;
			lastY = y;
			x = snake.body.get(thisSize - 1).lastX;
			y = snake.body.get(thisSize - 1).lastY;
		}
	}

	
	public int getX() {
		return x;
	}
	
	public int getY() {
		return y;
	}
	@Override
	public void render(Graphics g) {
		g.setColor(Game.snakeBodyColor);
		g.fillRect(x, y, Game.TILE_SIZE, Game.TILE_SIZE);
	}
}
