package tileBasedMovement.src.main;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontFormatException;
import java.awt.Graphics;
import java.awt.image.BufferStrategy;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import tileBasedMovement.src.gfx.Display;
import tileBasedMovement.src.states.MainMenu;
import tileBasedMovement.src.states.State;

public class Game implements Runnable {
	
	// Screen variables
	public int width, height;
	public String title;
	
	// Creating a display object
	public Display display;
	
	// Thread Loop variables
	private Thread thread;
	private boolean running;
	
	// Graphics Variables
	private BufferStrategy bs;
	private Graphics g;
	
	// Tile Size VariablesS
	public static final int TILE_SIZE = 25;
	
	// Key Manager object
	private KeyManager keyManager;
	
	
	// Players Score
	public static int SCORE;
	
	// Snake Variables
	public static Color snakeHeadColor = Color.green;
	public static Color snakeBodyColor = Color.green;
	
	// Screen Color Variables
	public static Color backgroundColor = Color.DARK_GRAY;
	
	// Apple Color Variables
	public static Color appleColor = Color.red;
			
	// States
	private State mainMenu;
	
	// Game Clock Logic
	public int FPS = 15;
	private final double timePerTick = 1000000000 / FPS;
	private double delta;
	private long now;
	private long lastTime;
	
	// Game Font
	public static Font textFont;
	public static Font bigFont;
	public static Font mediumFont;
	
	
	public Game(int width, int height, String title) {
		this.height = height;
		this.title = title;
		this.width = width;
		delta = 0;
		keyManager = new KeyManager();
		running = false;
	}

	@Override
	public void run() {
		running = true;
		init();
		
		
		lastTime = System.nanoTime();
		long timer = 0;
		long ticks = 0;
		
		while(running) {
			
			now = System.nanoTime();
			delta += (now - lastTime) / timePerTick;
			timer += now - lastTime;
			lastTime = now;
			
			if(delta >= 1) {
				tick();
				render();
				ticks++;
				delta--;
			}
			if(timer >= 1000000000) {
				System.out.println("FPS: " + ticks);
				ticks = 0;
				timer = 0;
			}
			
		}
		
		
		
	}
	
	public synchronized void Start() {
		if(running)
			return;
		thread = new Thread(this);
		thread.run();
	}
	
	public synchronized void Stop() {
		if(!running)
			return;
		
			try {
				thread.join();
			} catch (InterruptedException e) {

				e.printStackTrace();
			}
	}
	
	private void tick() {
		keyManager.tick();
		
		if(State.getState() != null) {
			State.getState().tick();
		}
		
	}
	
	public void delay(int delayTime) {
		while(delta <= delayTime + 1) {
			now = System.nanoTime();
			delta += (now - lastTime) / timePerTick;
			lastTime = now;
		}
		delta = 1;
	}
	
	private void render() {
		bs = display.getCanvas().getBufferStrategy();
		if(bs == null) {
			display.getCanvas().createBufferStrategy(3);
			return;
		}
		g = bs.getDrawGraphics();
		
		g.clearRect(0, 0, width, height);
		g.setColor(backgroundColor);
		g.fillRect(0, 0, width, height);
		// Start Draws 
		if(State.getState() != null) {
			State.getState().render(g);
		}
		// Stop Draws
		
		bs.show();
		g.dispose();
	}
	
	private void init() {
		display = new Display(width, height, title);
		display.getJFrame().addKeyListener(keyManager);
		SCORE = 0;
		mainMenu = new MainMenu(this);
		State.setState(mainMenu);
		
		try {
			textFont = Font.createFont(Font.TRUETYPE_FONT, new FileInputStream(new File("zig.ttf"))).deriveFont(Font.PLAIN, 50);
			bigFont = Font.createFont(Font.TRUETYPE_FONT, new FileInputStream(new File("zig.ttf"))).deriveFont(Font.PLAIN, 150);
			mediumFont = Font.createFont(Font.TRUETYPE_FONT, new FileInputStream(new File("zig.ttf"))).deriveFont(Font.PLAIN, 100);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FontFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public KeyManager getKeyManager() {
		return keyManager;
	}
	
}
