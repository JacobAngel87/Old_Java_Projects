package tileBasedMovement.src.main;

import tileBasedMovement.src.gfx.Display;

public class Launcher {
	public static void main(String[] args) {
		Game game = new Game(1000, 1000, "Snake");
		game.Start();
	}
}
