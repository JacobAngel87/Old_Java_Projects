package tileBasedMovement.src.states;

import java.awt.Color;
import java.awt.Graphics;

import tileBasedMovement.src.main.Game;

public class DeathState extends State {
	
	private Game game;
	private String finalScore;
	
	public DeathState(Game game) {
		this.game = game;
		finalScore = Integer.toString(game.SCORE / 2);
	}
	
	@Override
	public void tick() {
		
		if(game.getKeyManager().shift == true) {
			State mainMenu = new MainMenu(game);
			State.setState(mainMenu);
		}
	}

	@Override
	public void render(Graphics g) {
		g.setColor(Color.black);
		g.fillRect(0, 0, game.width, game.height);
		g.setFont(Game.mediumFont);
		g.setColor(Color.white);
		g.drawString("YOU LOST!", 150, 200);
		g.setFont(Game.textFont);
		g.drawString("Your score was " + finalScore , 175, 400);
		g.drawString("Press Shift to", 200, 600);
		g.drawString("play again", 275, 675);
		
	}

}
