package tileBasedMovement.src.states;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.Random;

import tileBasedMovement.src.entity.Apple;
import tileBasedMovement.src.entity.Snake;
import tileBasedMovement.src.main.Game;

public class GameState extends State {
	
	private Game game;
	private int tileSize;
	private Snake snake;	
	private Apple apple;
	private Random rand;
	
	public static Rectangle snakeBounds;
	private Rectangle appleBounds;
	
	
	public GameState(Game game) {
		this.game = game;
		tileSize = game.TILE_SIZE;
		game.SCORE = 0;
		rand = new Random();
		snake = new Snake(500, 450, game);
		
		int appleX = rand.nextInt(game.width / tileSize);
		appleX *= tileSize;
		
		int appleY = rand.nextInt(game.height / tileSize);
		appleY *= tileSize;
		
		apple = new Apple(appleX, appleY, game);
		
		snakeBounds = new Rectangle();
		snakeBounds.width = tileSize;
		snakeBounds.height = tileSize;
		
		appleBounds = new Rectangle();
		appleBounds.width = tileSize;
		appleBounds.height = tileSize;
	}

	@Override
	public void tick() {
		snake.tick();
		apple.tick();
		
		snakeBounds.x = snake.getX();
		snakeBounds.y = snake.getY();
		appleBounds.x = apple.getX();
		appleBounds.y = apple.getY();
		
		
		if(snakeBounds.intersects(appleBounds)) {
			apple.eaten();
			snake.grow();
			Game.SCORE += 1;
		}
	}

	@Override
	public void render(Graphics g) {
		
		g.setColor(Color.red);
		 for(int i = 0; i < game.width / tileSize; i++) {
			 for(int j = 0; j < game.height / tileSize; j++) {
				 g.drawRect(i * tileSize, j * tileSize, tileSize, tileSize);
			 }
		 }
		 
		 snake.render(g);
		 apple.render(g);
		 
	}
	
	public Rectangle getSnakeRect() {
		return snakeBounds;
	}
}
