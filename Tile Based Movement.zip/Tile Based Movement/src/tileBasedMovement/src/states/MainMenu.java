package tileBasedMovement.src.states;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

import tileBasedMovement.src.main.Game;

public class MainMenu extends State {

	private Game game;	
	private Color theColor;
	private int r, g, b;
	
	public MainMenu(Game game) {
		this.game = game;
		r = 255;
		g = 255;
		b = 255;
		theColor = new Color(r, g, b);
	}
	
	@Override
	public void tick() {
		
		if(game.getKeyManager().enter == true) {
			State gameState = new GameState(game);
			State.setState(gameState);
		}	
		
		if(r > 1 && g != 0 && b != 0) {
			r -=5;
		}
		else if(r != 255 && g != 0 && b > 1) {
			b -= 5;
		}
		else if(r != 255 && g > 1 && b != 255) {
			g -= 5;
			r +=5;
		}
		else if(r != 0 && g != 255 && b < 254) {
			b+=5;
		}
		else if(r > 1 && g != 255 && b > 1) {
			g += 5;
		}
	
		theColor = new Color(r,g ,b);
	}

	@Override
	public void render(Graphics g) {
		g.setColor(Color.black);
		g.fillRect(0, 0, game.width, game.height);
		g.setColor(theColor);
		g.setFont(Game.bigFont);
		g.drawString("SNAKE", 200, 275);
		g.setFont(game.textFont);
		g.setColor(Color.white);
		g.drawString("Press Enter to start!", 80, 550);
		
	}

}
