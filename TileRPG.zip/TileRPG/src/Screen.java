
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import java.util.Random;


import javax.swing.JPanel;

import snake.entities.Apple;
import snake.entities.Dirt;

public class Screen extends JPanel implements Runnable {

	
	public static final int WIDTH = 1100, HEIGHT = 1000; 
	
	private Thread thread;
	private boolean running = false;
	
	
	private int x = 20, y = 20;
	
	
	private Apple apple;
	private ArrayList<Apple> apples;
	private Dirt dirt;
	private ArrayList<Dirt> dirts;
	private Random r;
	public Color[] colors = new Color[13];
	
	
	private Key key;
	
	

	
	private Color foregroundColor1, foregroundColor2,backgroundColor;
	
	private int b1, f1, f2;
	
	public Screen() {
		
		
		setFocusable(true);
		
		
		key = new Key();
		
		r = new Random();
		
		setPreferredSize(new Dimension(WIDTH, HEIGHT));
		
		addKeyListener(key);
		
		
		apples = new ArrayList<Apple>();
		dirts = new ArrayList<Dirt>();
		
		f1 = 4;
		f2 = 3;
		b1 = 0;
		
		colors[0] = Color.black;
		colors[1] = Color.lightGray;
		colors[2] = Color.gray;
		colors[3] = Color.darkGray;
		colors[4] = Color.blue;
		colors[5] = Color.cyan;
		colors[6] = Color.MAGENTA;
		colors[7] = Color.RED;
		colors[8] = Color.orange;
		colors[9] = Color.green;
		colors[10] = Color.pink;
		colors[11] = Color.yellow;
		colors[12] = Color.white;
		
		foregroundColor1 = colors[f1];
		foregroundColor2 = colors[f2];
		backgroundColor = colors[b1];
		
		
		
		
		start();
	}
    
	
	
	
	public void tick() {
		
		if (apples.size() == 0) {
			int ma = 0;
			while(ma < 1000) {
			int x = r.nextInt(58);
			int y = r.nextInt(50);
			
			
			
			apple = new Apple(x, y, 20);
			apples.add(apple);
			ma++;
			}
		}
		
		if (dirts.size() == 0) {
			int md = 0;
		while(md < 1000) {	
			int x = r.nextInt(58);
			int y = r.nextInt(50);
			
			dirt = new Dirt(x, y, 20);
			dirts.add(dirt);
			md++;
		}
		}
	 
	}
	
	
	public void paint(Graphics g) {
		
		g.clearRect(x, y, WIDTH, HEIGHT);
		
		g.setColor(Color.black);
		
		for(int i = 0; i < WIDTH / 20; i ++) {
			g.drawLine(i * 20, 0, i * 20, HEIGHT );
		}
		
		for(int i = 0; i < HEIGHT / 20; i ++) {
			g.drawLine(0, i * 20, WIDTH, i * 20);
		}
		g.setColor(backgroundColor);
		g.fillRect(0, 0, WIDTH, HEIGHT);
		
		
		
		for(int i = 0; i < apples.size(); i ++) {
			
				apples.get(i).draw(g, foregroundColor1);
			 }
		
		
		for(int i = 0; i < dirts.size(); i ++) {
			
			dirts.get(i).draw(g, foregroundColor2);
		 }
		
        
        }
		 
	
	
	public void start() {
		running = true;
		thread = new Thread(this);
		thread.start();
	}
	
	public void stop() {
	    
		running = false;
		
		
		
		try {
			thread.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public void run() {
		while(running) {
			tick();
			repaint();
			
		}
		
		
	}
	
	private class Key implements KeyListener {

		@Override
		public void keyTyped(KeyEvent e) {
		
			
		}

	
		public void keyPressed(KeyEvent e) {
		
			int key = e.getKeyCode();
		
		if (key == KeyEvent.VK_RIGHT || key == KeyEvent.VK_G) {
			f2++;
			if(f2 == 13) {
				f2 = 0;
				foregroundColor2 = colors[f2];
			}
			else {
				
			
			
			foregroundColor2 = colors[f2];
			}
		}
		
		if (key == KeyEvent.VK_LEFT || key == KeyEvent.VK_G) {
			f1++;
			if(f1 == 13) {
				f1 = 0;
				foregroundColor1 = colors[f1];
			}
			else {
				
			
			
			foregroundColor1 = colors[f1];
			}
			
		}
		
		if (key == KeyEvent.VK_DOWN || key == KeyEvent.VK_G) {
			
			b1++;
			if(b1 == 13) {
				b1 = 0;
				backgroundColor = colors[b1];
			}
			else {
				
			
			
			backgroundColor = colors[b1];
			}
			
		}
		
		}

		@Override
		public void keyReleased(KeyEvent e) {
			
			
		}
		
	}
	
	
	
}
